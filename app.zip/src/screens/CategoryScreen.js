import React, { useState, useCallback, useEffect, useRef } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, FlatList, SafeAreaView, Modal, Animated } from 'react-native';
import Icon from 'react-native-vector-icons/MaterialIcons';
import CategoryCard from '../components/CategoryCard';
import Header from '../components/Header';
import { colors, spacing } from '../theme/theme';
import FoodDetailScreen from './FoodDetailScreen';

const CategoryScreen = ({ route, navigation }) => {
  const { category } = route.params;
  const [data, setData] = useState([]);
  const [isModalVisible, setIsModalVisible] = useState(false);
  const [selectedItem, setSelectedItem] = useState(null);

  const colorAnimation = useRef(new Animated.Value(0)).current;
  
  useEffect(() => {
    Animated.loop(
      Animated.sequence([
        Animated.timing(colorAnimation, {
          toValue: 1,
          duration: 3000,
          useNativeDriver: false
        }),
        Animated.timing(colorAnimation, {
          toValue: 0,
          duration: 3000,
          useNativeDriver: false
        })
      ])
    ).start();
  }, []);

  const backgroundColor = colorAnimation.interpolate({
    inputRange: [0, 1],
    outputRange: ['rgba(255,255,255,1)', 'rgba(0,128,128,1)']
  });

  const handleCardPress = useCallback((item) => {
    setSelectedItem(item);
    setIsModalVisible(true);
  }, []);

  const handleCloseModal = () => {
    setIsModalVisible(false);
    setSelectedItem(null);
  };

  const renderItem = ({ item, index }) => (
    <CategoryCard
      item={item}
      index={index}
      handleCardPress={() => handleCardPress(item)}
    />
  );

  return (
    <Animated.SafeAreaView style={[styles.safeArea, { backgroundColor }]}>
      <View style={styles.container}>
        <Header navigation={navigation} title={category} />
        <FlatList
          data={data}
          renderItem={renderItem}
          keyExtractor={(item) => item.name}
          numColumns={1}
          showsVerticalScrollIndicator={false}
          ListHeaderComponent={
            <Text style={styles.catchPhrase}>Dive into the World of {category} Delights!</Text>
          }
        />
        {selectedItem && (
          <Modal
            visible={isModalVisible}
            animationType="slide"
            transparent={true}
            onRequestClose={handleCloseModal}
          >
            <FoodDetailScreen item={selectedItem} closeModal={handleCloseModal} navigation={navigation} />
          </Modal>
        )}
        <TouchableOpacity style={styles.fab} onPress={() => console.log('Checkout Pressed')}>
          <Text style={styles.fabText}>Items in your basket</Text>
          <Icon name="shopping-cart" size={24} color="white" />
        </TouchableOpacity>
      </View>
    </Animated.SafeAreaView>
  );
};

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: colors.background,
  },
  container: {
    flex: 1,
  },
  catchPhrase: {
    fontSize: 20,
    color: colors.primary,
    fontWeight: 'bold',
    textAlign: 'center',
    marginVertical: 20,
  },
  fab: {
    position: 'absolute',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    width: '100%',
    height: 60,
    backgroundColor: colors.primary,
    bottom: 0,
    paddingHorizontal: 30,
    borderTopRightRadius: 25,
    borderTopLeftRadius: 25,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
    elevation: 5,
  },
  fabText: {
    color: 'white',
    fontSize: 18,
    fontWeight: 'bold',
    marginRight: 10,
  },
});

export default CategoryScreen;
